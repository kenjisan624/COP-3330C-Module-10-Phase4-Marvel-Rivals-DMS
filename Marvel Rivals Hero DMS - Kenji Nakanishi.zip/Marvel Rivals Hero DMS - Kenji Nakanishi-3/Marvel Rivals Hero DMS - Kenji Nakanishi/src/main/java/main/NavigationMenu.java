package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;

import java.util.List;

// Custom method to create a PDF file
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;



// Holding the display where user will be able to see the menu, basically it has 8 options that can be easily selected.
// User can select an option by typing the number on their keyboard.
// I try to improve my previous patron code and added more functionalities
public class NavigationMenu {
    private Path SAVE_FILE;
    private final HashMap<String, Hero> heroRecords = new HashMap<>();
    private final Scanner In = new Scanner(System.in);

    public void start() {
        // I have included a csv file for current season with the 42 characters data// Marvel Rivals.com
        System.out.println("""
                ******************************************************************************
                *                       Marvel Rivals Data Management System                 *
                ******************************************************************************
                | You can also select [6] and copy path:                                     |
                |                                                                            |
                | FROM IntelliJ: out/artifacts/MarvelRivalsApp_jar/Season1WinRate.csv        |
                | FROM JAR Application: Season1WinRate.csv                                   |
                |                                                                            |""");

        while (true) {
            DisplayNavigation();
            String selection = In.nextLine().trim();
            switch (selection) {
                // Methods have been organized in CRUD + Custom method
                case "1" -> CreateMHero();
                case "2" -> RemovingByid();
                case "3" -> UpdateMRHero();
                case "4" -> DisplayAllData();
                case "5" -> SearchHeroByID();
                case "6" -> LoadFromTxtFile();
                case "7" -> GenerateWinRateReport();
                case "8" -> {
                    save();
                    System.out.println("Exiting Marvel Rivals Data Management System. BYE BYE!");
                    return;
                }
                default -> System.out.println("Invalid selection. Try again.");
            }
            System.out.println();
        }
    }

    // I have these options printed to the user every time the application runs.
    public void DisplayNavigation() {
        // This time, user can interact with more option than the previous project; we have update, search, and generate report in PDF.
        System.out.println("""
                ******************************************************************************
                *                               Selection Menu:                              *
                ******************************************************************************
                [1] Create Marvel Rivals Hero     [5] Search Hero by ID
                [2] Remove Heros by ID            [6] Load Heros from file
                [3] Update Hero's Data            [7] Generate Report by Win Rate
                [4] Display Hero Data             [8] Exit
                
                Selection:""");
    }


    // Fixing input of user while creating a new Marvel Rival Hero



    // Boolean CreateMRhero will allow user to add their own record to the DMS.
    // it will contain a basic instructions that the user can follow accompanied by the allow range easily highlighted to avoid confusion
    public boolean CreateMHero() {

        System.out.println
                ("""
                         INSTRUCTIONS:\s
                        You will be prompted to enter Hero's data in the sequential order:
                        1. Hero Identity ID \s
                        2. Hero Name \s
                        3. Health Point \s
                        4. Movement Speed \s
                        5. Ultimate Damage \s
                        6. Hero Role\s
                        7. Win Rate\s
                                                """);

        // 1. Hero Identity ID
        System.out.println("ALLOWED FORMAT: 3-Digits from #0~9, no characters nor symbols!\n " +
                "1. Please enter HERO IDENTITY ID:");
        String threeDigitsID = In.nextLine().trim();
        // 2. Hero Name
        System.out.print("\nALLOWED FORMAT: Up to 3 words: Example: Jeff The LandShark, Rocket Racoon. \n"
                + "2.Please, type HERO NAME: \n");
        String heroNameTyping = In.nextLine().trim();

        // Integers usage!
        int  healthPoint, movementSpeed, ultDamage;

        // 3. Health Point
        System.out.print("\nALLOWED FORMAT: Only number from 250 ~ 900 HP. /// Do not include HP \n");
        System.out.print("3. Please type HEALTH POINT: \n");
        Integer hp = HealthPointFormat(In.nextLine().trim());

        // 4. Movement Speed
        System.out.print("\nALLOWED FORMAT: Only number from 6 ~ 9 m/s. // Do not include m/s.  \n");
        System.out.print("4. Please type MOVEMENT SPEED: \n");
        Integer ms = MovementSpeedFormat(In.nextLine().trim());


        // 5. Ultimate Damage
        System.out.print("\nALLOWED FORMAT: Only number from 300 ~ 9999. \n");
        System.out.print("5. Please type ULTIMATE DAMAGE: \n");
        Integer ud = UltDamageFormat(In.nextLine().trim());


        // 6. Hero Role
        System.out.print("\nALLOWED FORMAT: Duelist, Strategist, or Vanguard. // First Letter Capital or not is okay! D,S,V \n"
                + "6.Please, type HERO ROLE: \n");
        String heroRoleTyping = In.nextLine().trim();
        // 7.Win Rate
        System.out.print("\nALLOWED FORMAT: from 0.00 ~ 100.00. DO NOT INCLUDE % \n"
                + "7.Please, type WIN  RATE: \n");
        String winRateTyping = In.nextLine().trim();


        // Including the ErrorInEntry section which will check for error in the user entries
        boolean ErrorInEntry = false;
        if (!HeroIdFormat(threeDigitsID)) {
            System.out.println("\n ERROR: Verify format must be 3-Digits only!");
            ErrorInEntry = true;
        } else if (heroRecords.containsKey(threeDigitsID)) {
            System.out.println("\n DUPLICATE ERROR: Hero already exists!");
            ErrorInEntry = true;
        }


        if (heroNameTyping.isEmpty() || heroRoleTyping.isEmpty()) {
            System.out.println("\n ERROR: Name, Health Point, movement speed, ultimate damage cannot be empty");
            ErrorInEntry = true;
        }
        Double winRate = WinRateFormat(winRateTyping);
        if (winRate == null) {
            System.out.println("\n Error: Win rate must be between 0.00 ~ 100.00%");
            ErrorInEntry = true;
        }

        if (hp == null) {
            System.out.println("\n ERROR: Health Point must be between 250 and 900!");
            ErrorInEntry = true;
            healthPoint = 250;
        } else {
            healthPoint = hp;
        }

        if (ms == null) {
            System.out.println("\n ERROR: Movement Speed must be between 6 to 9");
            ErrorInEntry = true;
            movementSpeed = 6;
        } else {
            movementSpeed = ms;
        }

        if (ud == null) {
            System.out.println("\n ERROR: Movement Speed must be between 6 to 9");
            ErrorInEntry = true;
            ultDamage = 300;
        } else {
            ultDamage = ud;
        }



        // These booleans Error Identifier will help the validation and will flag them with error later in the if-statements
        boolean identityHeroIDError = !HeroIdFormat(threeDigitsID) || heroRecords.containsKey(threeDigitsID);
        boolean nameError = heroNameTyping.isEmpty() || heroNameTyping.split("\\s+").length > 3;
        boolean healthPointError = (healthPoint < 250 || healthPoint > 900);
        boolean movementSpeedError = (movementSpeed < 6 || movementSpeed > 9);
        boolean ultDamageError = (ultDamage < 300 || ultDamage > 9999);
        boolean heroRoleError = heroRoleTyping.isEmpty() || HeroRoleFormat(heroRoleTyping) == null;
        boolean winRateError = (winRate == null);

        ErrorInEntry = identityHeroIDError || nameError || healthPointError || movementSpeedError || ultDamageError || heroRoleError || winRateError;

        // Prints to the user where the issue lies for easier detection; this will allow easier detection where the error has been found!
        // Whenever error is found, the program will add ***** asterisks to highlight further
        if (ErrorInEntry) {
            System.out.println("\nHERO RECORD NOT ADDED - Input with error has been marked with *****");
            System.out.println("\nIdentity Hero ID: " + threeDigitsID + (identityHeroIDError ? " *****" : " "));
            System.out.println("Hero Name: " + heroNameTyping + (nameError ? " *****" : " "));
            System.out.println("Health Point: " + healthPoint + (healthPointError ? " *****" : " "));
            System.out.println("Movement Speed: " + movementSpeed + (movementSpeedError ? " *****" : " "));
            System.out.println("Ultimate Damage: " + ultDamage + (ultDamageError ? " *****" : " "));
            System.out.println("Hero Role: " + heroRoleTyping + (heroRoleError ? " *****" : " "));
            System.out.println("Win rate: " + winRateTyping + (winRateError ? " *****" : " "));
            return false;
        }

        //If the user entered correctly all the hero data, then those details will be confirmed!
        heroRecords.put(threeDigitsID, new Hero(threeDigitsID, heroNameTyping, healthPoint, movementSpeed, ultDamage, heroRoleTyping, winRate));
        save();
        System.out.println("Adding new hero");
        System.out.println("\n Hero has been added successfully!");
        System.out.println(" Added Hero information: " +
                "\n Hero Identity ID: " + threeDigitsID +
                "\n Hero Name: " + heroNameTyping +
                "\n Health Point: " + healthPoint +
                "\n Movement Speed: " + movementSpeed +
                " \n Ultimate Damage: " + ultDamage +
                "\n Hero Role: " + heroRoleTyping +
                " \n Win rate: " + winRateTyping);
        return true;
    }

    // Validation Methods for ID format, Role format, Win Rate format
    // This will make sure the ID contains only 3 digits such as 012, 777, but not 1000
    public boolean HeroIdFormat(String threeDigitsID) {
        return threeDigitsID != null && threeDigitsID.matches("\\d{3}");
    }

    public Integer HealthPointFormat(String healthPoint) {
        try {
            int value =  Integer.parseInt(healthPoint);
            if (value < 250 || value > 900) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public Integer MovementSpeedFormat(String movementSpeed) {
        try {
            int value =  Integer.parseInt(movementSpeed);
            if (value < 6 || value > 9) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }

    public Integer UltDamageFormat(String ultDamage) {
        try {
            int value =  Integer.parseInt(ultDamage);
            if (value < 300 || value > 9999) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }



    // For Hero Role, user can type either in capital or not the first letter
    public String HeroRoleFormat(String roleTyping) {
        if (roleTyping == null) return null;
        String roles = roleTyping.trim().toLowerCase(Locale.ROOT);
        return switch (roles) {
            case "duelist" -> "Duelist";
            case "strategist" -> "Strategist";
            case "vanguard" -> "Vanguard";
            default -> null;
        };
    }

    // This will set and limit the value user enter between 0~100
    public Double WinRateFormat(String winRateTyping) {
        try {
            double value = Double.parseDouble(winRateTyping);
            if (value < 0.00 || value > 100.00) return null;
            return value;
        } catch (NumberFormatException e) {
            return null;
        }
    }





    // RemovingByid will verify first if the list is empty, if not will proceed to ask the 3-Digits ID, print
    // confirmation panel to later remove the ID from the DMS, I have also added the functionality to print list after removing ID.
    public boolean RemovingByid() {
        if (heroRecords.isEmpty()) {
            System.out.println("*** ERROR: Heroes list is EMPTY!. ***");
            return false;
        }
        // Prompt to enter the Hero ID to remove
        System.out.print("Enter 3-Digit Hero ID to REMOVE: ");
        String threeDigitsID = In.nextLine().trim();
        // This will check if any Heroes were previously entered
        Hero HID = heroRecords.get(threeDigitsID);
        if (HID == null) {
            System.out.println("*** ERROR: Hero ID not found!. ***");
            return false;
        }
        // This will show the Hero information making sure this is the data you want to erase:
        System.out.println("This correspond to: \n" + HID);
        // Start a while loop to ask for user selection Y or N
        while (true) {
            System.out.println("Please confirm you want to remove this hero? (y/n); ");
            String confirmation = In.nextLine().trim();
            // for Yes = y and Y
            if (confirmation.equals("y") || confirmation.equals("Y")) {
                heroRecords.remove(threeDigitsID);
                save();

                System.out.println("Hero list in Ascending order by Identity Hero ID: \n");
                java.util.List<String> ids = new java.util.ArrayList<>(heroRecords.keySet());
                Collections.sort(ids);
                for (String id : ids) {
                    System.out.println(heroRecords.get(id));
                }
                System.out.println("Hero have been removed successfully!\n\n");
                return true;
            } else if (confirmation.equals("n") || confirmation.equals("N")) {
                System.out.println("Cancelled");
                return false;
                // in case other character was entered loop again.
            } else {
                System.out.println("INVALID!, please enter Y for yes & N for no");
            }
        }
    }


    // UdateMRHero will check first for existing list, if not empty will proceed to
    // ask the user for the ID that wants to be updated, I followed the same formatting from CreatingMRhero so
    // program seems seamless throughout all portions.

    public boolean UpdateMRHero() {
        if (heroRecords.isEmpty()) {
            System.out.println("*** ERROR: Heroes list is EMPTY!. ***");
            return false;
        }
        System.out.println("Enter 3-Digits Hero ID to update: ");
        String threeDigitsID = In.nextLine().trim();

        Hero HID = heroRecords.get(threeDigitsID);
        if (HID == null) {
            System.out.println("*** ERROR: Hero ID not found!. ***");
            return false;
        }
        System.out.println("This correspond to: \n" + HID);

        while (true) {
            System.out.println("Please confirm you want to update this hero? (y/n); ");
            String confirmation = In.nextLine().trim();

            if (confirmation.equals("y") || confirmation.equals("Y")) {
                // Prompt for new Name
                System.out.print("\nALLOWED FORMAT: Up to 3 words: Example: Jeff The LandShark, Rocket Racoon.\n");
                System.out.println("\n Please type NEW  HERO NAME: ");

                // Validate is only three words
                String newName = In.nextLine().trim().replaceAll("\\s+", " ");
                if (newName.isEmpty()) newName = HID.getHeroName();
                boolean nameError = newName.split("\\s+").length > 3;

                // Since Health Point, Movement Speed, and Ultimate Damage are Integer, I needed to
                // Parse them!
                Integer newHP = null;
                while (true) {
                    System.out.print("\nALLOWED FORMAT: Only number from 250 ~ 900 HP. /// Do not include HP \n");
                    System.out.print("Please type NEW HEALTH POINT: ");
                    String s = In.nextLine().trim();
                    if (s.isEmpty()) {
                        newHP = HID.getHealthPoint();
                        break;
                    }
                    try {
                        int v = Integer.parseInt(s);
                        if (v < 250 || v > 900) {
                            System.out.println("  -> Must be 250–900.");
                            continue;
                        }
                        newHP = v;
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("  -> Enter an integer allowed.");
                    }
                }

                Integer newSpeed = null;
                while (true) {
                    System.out.print("\nALLOWED FORMAT: Only number from 6 ~ 9 m/s. // Do not include m/s.  \n");
                    System.out.print("Please type NEW Movement Speed: ");
                    String s = In.nextLine().trim();
                    if (s.isEmpty()) {
                        newSpeed = HID.getMovementSpeed();
                        break;
                    }
                    try {
                        int v = Integer.parseInt(s);
                        if (v < 6 || v > 9) {
                            System.out.println("ERROR: Must be 6~9.");
                            continue;
                        }
                        newSpeed = v;
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println(" ERROR: Enter an integer allowed.");
                    }
                }

                Integer newUlt = null;
                while (true) {
                    System.out.print("\nALLOWED FORMAT: Only number from 300 ~ 9999. \n");
                    System.out.print("please type NEW ULTIMATE DAMAGE: ");
                    String s = In.nextLine().trim();
                    if (s.isEmpty()) {
                        newUlt = HID.getUltDamage();
                        break;
                    }
                    try {
                        int v = Integer.parseInt(s);
                        if (v < 300 || v > 9999) {
                            System.out.println(" ERROR: Must be 300~9999.");
                            continue;
                        }
                        newUlt = v;
                        break;
                    } catch (NumberFormatException e) {
                        System.out.println("ERROR: Enter an integer allowed.");
                    }
                }

                System.out.print("\nALLOWED FORMAT: Duelist, Strategist, or Vanguard. // First Letter Capital or not is okay! D,S,V \n");
                        System.out.print("Please type NEW HERO ROLE: ");
                String roleIn = In.nextLine().trim();
                String newRole = roleIn.isEmpty() ? HID.getHeroRole() : HeroRoleFormat(roleIn); // reuse code that I did for CreateMRhero
                boolean roleError = (newRole == null);

                Double newWR = null;
                while (true) {
                    System.out.print("\nALLOWED FORMAT: from 0.00 ~ 100.00. DO NOT INCLUDE % \n");
                            System.out.print("Please type NEW WIN RATE: ");
                    String s = In.nextLine().trim();

                    if (s.isEmpty()) {
                        newWR = HID.getWinRate();
                        break;
                    }
                    newWR = WinRateFormat(s); // same code reuse for this portion as well from CreateMRhero
                    if (newWR == null) {
                        System.out.println("ERROR: Must be a number 0.00~100.00.");
                        continue;
                    }
                    break;
                }
                if (nameError || roleError) {
                    System.out.println("\nUPDATE FAILED!, Please verify entries!");
                    if (nameError) System.out.println("Hero name must be from 1 to up to 3 words.");
                    if (roleError) System.out.println("Hero role must be Duelist/Strategist/Vanguard.");
                    return false;
                }

                Hero updateHero = new Hero(threeDigitsID, newName, newHP, newSpeed, newUlt, newRole, newWR);
                heroRecords.put(threeDigitsID, updateHero);
                save();
                System.out.println("Hero has been updated SUCCESSFULLY!\n");
                System.out.println(updateHero);
                return true;
            }
        }
    }


    // The DisplayAllData basically check if list in empty, if not it will print all the stored heroRecords
    public List<Hero> DisplayAllData() {
    if(heroRecords.isEmpty()) {
        System.out.println("No Hero records to display.");
        return Collections.emptyList();
        }
        List<String> heroIDs = new ArrayList<>(heroRecords.keySet());
        heroIDs.sort(Comparator.comparingInt(Integer::parseInt));
        System.out.println("Hero list in Ascending order by Identity Hero ID: \n");
        for (String threeDigitsID : heroIDs) {
            System.out.println(heroRecords.get(threeDigitsID));
        }
        return heroIDs.stream().map(heroRecords::get).toList();
    }


    // SearchHeroBYID will prompt user to type an ID to later look for it and print those details
    public Hero SearchHeroByID() {
        if(heroRecords.isEmpty()) {
            System.out.println("No Hero records to search from...");
            return null;
        }
        System.out.println("Enter 3-Digits Hero ID to Search from: ");
        String threeDigitsID = In.nextLine().trim();

        Hero hero = heroRecords.get(threeDigitsID);
        if (hero == null) {
            System.out.println("*** ERROR: Hero ID not found!. ***");
            return null;
        }
        System.out.println("This correspond to: \n" + hero);
        return hero;
    }


    // LoadFromTxtFile it can be used for csv file as well and this time I have added the csv file with the current season information
    // I have used this portion from patron project since it was similar action that I needed to add
    public void LoadFromTxtFile(){
        System.out.print("INSTRUCTIONS: You can type your own file path\n" +
                "\nSample data path: "+
                "\nFROM IntelliJ: out\\artifacts\\MarvelRivalsApp_jar\\Season1WinRate.csv"+
                "\nFROM JAR Application: Season1WinRate.csv"+
                "\nEnter File Path: ");

    String TxtPath = In.nextLine().trim();
        if ( (TxtPath.startsWith("\"") && TxtPath.endsWith("\"")) ||(TxtPath.startsWith("'") && TxtPath.endsWith("'")) ) {
            TxtPath = TxtPath.substring(1, TxtPath.length()-1).trim();
        }

        Path path;
        try {
            path = Paths.get(TxtPath);
        } catch (Exception e) {
            System.out.println("*** ERROR: Invalid file path ***");
            return;
        }
        if(!Files.exists(path)) {
            System.out.println("*** ERROR: File doesn't exist. ***");
            return;
        }
        // For interface and interactivity:
        // Adding a counter indicator for line order, added values, duplicates, error and skipped values has been introduced.
        int lineInTxt = 0, SuccessfullyAdded = 0, DuplicatesValue = 0, Errors = 0, Skipped = 0;
        try (BufferedReader reader = Files.newBufferedReader(Paths.get(TxtPath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                lineInTxt++;
                line = line.trim();
                if (line.isEmpty()) continue;

                // This part will separate whenever a dash is found.
                String[] info = line.split("-", 7);
                // Whenever finds a line that does not contain all 7 records will be skipped and count towards the skip count.
                if (info.length !=7) {
                    System.out.println("line number: " + lineInTxt + ": has been skipped.");
                    Skipped++;
                    continue;
                }
                //Important: Dividing in 7 parts:
                String identityHeroID       = info[0].trim(); // before 1st dash will hold identityHeroID
                String heroName             = info[1].trim(); // This part will hold heroName
                int healthPoint          = Integer.parseInt(info[2].trim()); // healthPoint will be held in the third section
                int movementSpeed        = Integer.parseInt(info[3].trim()); // movementSpeed information in Integer format
                int ultDamage            = Integer.parseInt(info[4].trim()); // ultDamage information in Integer format
                String heroRole             = info[5].trim(); // heroRole information in String format
                String WinRateInString      = info[6].trim(); // WinRateInString information in String format

                // I used the regular expression to find a white space character and when find it separate them,
                String[] HeroNameParts = heroName.split("\\s+");
                // if there is less than two names or more, != 3 will detect as error
                if (HeroNameParts.length < 1 || HeroNameParts.length > 4) {
                    System.out.println("line number: " + lineInTxt + " | ERROR: Hero naming format incorrect: " + heroName);
                    Errors++;
                    continue;
                }

                // Whenever does not match with IdentityHeroID that has a regex of 7 number format
                if (!HeroIdFormat(identityHeroID)) {
                    System.out.println("line number: " + lineInTxt + " | ERROR: Verify digits typed: " + identityHeroID);
                    Errors++;
                    continue;
                }
                // Whenever the WinRate format is not within range as specified in WinRateFormat
                Double winRate = WinRateFormat(WinRateInString);
                if (winRate == null) {
                    System.out.println("line number: " + lineInTxt + " | ERROR:Verify win rate typed: " + WinRateInString);
                    Errors++;
                    continue;
                }
                // Whenever the IdentityHeroID has been previously entered
                if (heroRecords.containsKey(identityHeroID)) {
                    System.out.println("line number: " + lineInTxt + " Skipped since DUPLICATE entries. " + identityHeroID);
                    DuplicatesValue++;
                    continue;
                }
                // If everything goes well, those heroes data passed the tests will be added successfully!
                heroRecords.put(identityHeroID, new Hero(identityHeroID, heroName, healthPoint, movementSpeed, ultDamage,heroRole, winRate));
                SuccessfullyAdded++;
            }
        } catch (IOException i) {
            System.out.println("I/O error: " + i.getMessage());
            return;
        }

        // This will storage the path so when hit exit it will be saved to the chosen path.
        this.SAVE_FILE = path;
        // Print in the user screen the loading animation that the data is being loaded to add interactivity same 750 milliseconds
        System.out.println("Loading Heroes from Text / CSV file.");
        for (int i = 0; i < 3; i++) {
            try {
                Thread.sleep(750); //three / quarter of a second
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
            System.out.print("..");
        }
        // Print to the user what has been counted!
        System.out.printf("\nDone! \nHeroes that were added: %d, duplicates: %d, errors: %d, Skipped: %d",
                SuccessfullyAdded, DuplicatesValue, Errors, Skipped);
    }

    // Custom Method: This method was my desire of creating the report of the characters data
    // PDF format output that is organized by win rate
    // WinRate calculations has been obtained by accessing MarvelRivals.com
    public Path GenerateWinRateReport(){
        if(heroRecords.isEmpty()){
            System.out.println("*** ERROR: Empty Heroes! ***");
            return null;
        }
        // Win rate sorting
        List<Hero> heroList = new ArrayList<>(heroRecords.values());
        heroList.sort(Comparator.comparingDouble(Hero::getWinRate).reversed());

        // Here we can specify the name of the report we want to assign
        String fileName = "WinRate-Report.pdf";
        Path outputPath = Paths.get(fileName);

        try {
            // Here we can give formatting to the PDF by assigning the output values.
            // https://www.baeldung.com/java-pdf-creation
            // Future improvement: Use Marvel Rivals font for DB!  https://www.dafontfree.io/refrigerator-deluxe-font-family/
            // This part can be customized as we please, for this Phase I, I have tried using colours from Marvel Rivals, but for the DB We can be more creative
            Document document = new Document(PageSize.A4);
            PdfWriter.getInstance(document, new FileOutputStream(outputPath.toFile()));

            document.open();

            // work in progress for next phases!
            /*try {
                 Image img = Image.getInstance("src/main/resources/MR_Logo.png");
                 img.scaleToFit(100, 100);

                 img.setAbsolutePosition(
                         PageSize.A4.getWidth() - img.getScaledWidth() - 50,
                         PageSize.A4.getHeight() - img.getScaledHeight() - 50
                         );
                 document.add(img);
            } catch(DocumentException de) {
                System.out.println(de.getMessage());
            }*/

            Font titleFont = new Font(Font.FontFamily.TIMES_ROMAN, 22, Font.BOLD, BaseColor.BLACK);
            document.add(new Paragraph("Marvel Rivals Heroes Win Rate % Report", titleFont));
            document.add(new Paragraph(" ", titleFont));

            Font commentFont = new Font(Font.FontFamily.HELVETICA, 12, Font.ITALIC, BaseColor.GRAY);
            Paragraph comment = new Paragraph("WELCOME! This is the report created by selecting [7] Generate Report By Win Rate; This has been organized by the Win Rate which we have obtained from Marvel Rivals.com! ", commentFont);
            comment.setAlignment(Paragraph.ALIGN_CENTER);
            document.add(comment);

            document.add(new Paragraph(" "));

            PdfPTable table = new PdfPTable(7);
            table.setWidthPercentage(100);
            table.setWidths(new float[]{1.2f, 2.5f, 1.2f, 1.2f, 1.5f, 2f, 1.5f});

            Font headerFont = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.WHITE);
            BaseColor headerColor = new BaseColor(255, 0, 0);

            String[] headers = {"ID", "Hero Name", "Health Point", "Mov. Speed", "Ultimate Damage", "Hero Role", "Win Rate (%)"};
            for (String header : headers) {
                PdfPCell cell = new PdfPCell(new Phrase(header, headerFont));
                cell.setBackgroundColor(headerColor);
                cell.setHorizontalAlignment(Element.ALIGN_CENTER);
                table.addCell(cell);
            }

            Font dataFont = new Font(Font.FontFamily.HELVETICA, 11);
            for (Hero h : heroList) {
                table.addCell(h.getIdentityHeroID());
                table.addCell(h.getHeroName());
                table.addCell(Integer.toString(h.getHealthPoint()));
                table.addCell(Integer.toString(h.getMovementSpeed()));
                table.addCell(Integer.toString(h.getUltDamage()));
                table.addCell(h.getHeroRole());
                table.addCell(String.format("%.2f%%", h.getWinRate()));
            }
            document.add(table);
            document.close();
            System.out.println("Amazing!! PDF document was generated correctly! You can check it at: " + outputPath.toAbsolutePath());
        } catch (Exception e) {
            System.out.println("Something went wrong with the report generation....: " + e.getMessage());
        }
        return outputPath;
    }


    // save will as the name said save, this will be used when user press exit!
    // it will save on the current opened csv file or txt file!
    public boolean save() {
        if (SAVE_FILE == null) {
            System.out.println("\n>Saving in temporary Memory only...");
            return false;
        }
        List<String> ids = new ArrayList<>(heroRecords.keySet());
        Collections.sort(ids);
        try (BufferedWriter bw = Files.newBufferedWriter(SAVE_FILE)) {
            for (String id : ids) {
                bw.write(heroRecords.get(id).toFileLine());
                bw.newLine();
            }
            return true;
        } catch (IOException ioe) {
            System.out.println("Error saving " + ioe.getMessage());
            return false;
        }
    }
}
