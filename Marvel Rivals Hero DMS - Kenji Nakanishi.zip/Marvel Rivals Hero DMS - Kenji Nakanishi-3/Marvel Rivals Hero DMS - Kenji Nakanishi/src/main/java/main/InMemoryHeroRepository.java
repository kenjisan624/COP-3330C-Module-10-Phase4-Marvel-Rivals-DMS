package main;

import java.util.*;

public class InMemoryHeroRepository implements main.HeroRepository {
    private final Map<String, Hero> store = new HashMap<>();

    @Override public boolean save(main.Hero hero) {
        if (store.containsKey(hero.getIdentityHeroID())) return false;
        store.put(hero.getIdentityHeroID(), hero);
        return true;
    }

    @Override
    public Hero findById(String id) {
        return store.get(id);
    }

    @Override
    public List<main.Hero> findAll() {
        return new ArrayList<>(store.values());
    }

    @Override
    public boolean update(main.Hero hero) {
        if (!store.containsKey(hero.getIdentityHeroID())) return false;
        store.put(hero.getIdentityHeroID(), hero);
        return true;
    }
    @Override
    public boolean deleteById(String id) {
        return store.remove(id) != null;
    }

    @Override
    public boolean existsById(String id) {
        return store.containsKey(id);
    }
}
