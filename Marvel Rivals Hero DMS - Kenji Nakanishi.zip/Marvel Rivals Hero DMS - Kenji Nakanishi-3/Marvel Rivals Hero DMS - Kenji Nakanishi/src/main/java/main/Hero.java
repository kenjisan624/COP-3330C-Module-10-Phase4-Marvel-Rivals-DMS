package main;

import java.util.Locale;

public class Hero{

    public static final String FILE_DELIM = " - ";
    public static final String FILE_SPLIT_REGEX = "\\s*-\\s*";
        private final String identityHeroID;
        private final String heroName;
        private final int healthPoint;
        private final int movementSpeed;
        private final int ultDamage;
        private final String heroRole;
        private final double winRate;

   // Constructor
    public Hero (String identityHeroID, String heroName, int healthPoint, int movementSpeed,
                 int ultDamage, String heroRole, double winRate) {
        this.identityHeroID = identityHeroID;
        this.heroName = heroName;
        this.healthPoint = healthPoint;
        this.movementSpeed = movementSpeed;
        this.ultDamage = ultDamage;
        this.heroRole = heroRole;
        this.winRate = winRate;
    }

    // Getters
    public String  getIdentityHeroID() {
        return identityHeroID;
    }
    public String getHeroName() {
        return heroName;
    }
    public int getHealthPoint() {return healthPoint;}
    public int getMovementSpeed() {
        return movementSpeed;
    }
    public int getUltDamage() {return ultDamage;}
    public String getHeroRole(){
        return heroRole;
    }
    public double getWinRate(){
        return winRate;
    }

    //This will set the format to print on CLI
    @Override
    public String toString() {
        return String.format(Locale.ROOT, "%s - %s - %d - %d - %d - %s - %.2f%%", identityHeroID, heroName, healthPoint, movementSpeed, ultDamage, heroRole, winRate);
    }
    // This will set the format to storage on cvs and txt file
    public String toFileLine(){
        return String.format(Locale.ROOT, "%s" + FILE_DELIM + "%s" + FILE_DELIM + "%d" + FILE_DELIM + "%d" +
                        FILE_DELIM + "%d" + FILE_DELIM + "%s" + FILE_DELIM + "%.2f",
                identityHeroID, heroName, healthPoint, movementSpeed, ultDamage, heroRole, winRate);
    }
    public String toCsvLine() {
        return toFileLine();
    }

    public static Hero fromFileLine(String line) {
        if (line == null || line.trim().isEmpty() ) {
            throw new IllegalArgumentException("Empty or null");
        }
        String[] parts = line.split(FILE_SPLIT_REGEX,7);
        if (parts.length != 7) {
            throw new IllegalArgumentException("Invalid hero: " + line);
        }

        try {
            String id       = parts[0].trim();
            String name     = parts[1].trim();
            int hp          = Integer.parseInt(parts[2].trim());
            int move        = Integer.parseInt(parts[3].trim());
            int ult         = Integer.parseInt(parts[4].trim());
            String role     = parts[5].trim();
            String wrRaw    = parts[6].trim().replace("%", "");
            double rate     = Double.parseDouble(wrRaw);

            return new Hero(id, name, hp, move, ult, role, rate);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("Invalid hero: " + line, e);
        }
    }
}
