package main;

import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.List;

import com.itextpdf.text.*;
import com.itextpdf.text.pdf.*;

//Here is the logic validating, sorting and also importing.
// the PDF logic on how it is generate is in here as well.

// import have been reused from the previous phase
public class HeroFunctionalities {
    public static class ImportResult {
        public final int added, duplicates, errors, skipped;

        public ImportResult(int a, int d, int e, int s) {
            added = a;
            duplicates = d;
            errors = e;
            skipped = s;
        }

        @Override
        public String toString() {
            return "Imported: " + added + " | Duplicates: " + duplicates +
                    " | Errors: " + errors + " | Skipped: " + skipped;
        }
    }

    private final HeroRepository repo;
    public HeroFunctionalities(HeroRepository repo) {

        this.repo = repo;
    }
    public boolean addHero(Hero h) { validate(h); return repo.save(h); }
    public List<Hero> listHeroes() { return repo.findAll(); }
    public boolean updateMarvelHero(Hero h) { validate(h);  return repo.update(h); }
    public boolean removeMarvelHeroById(String id) {return repo.deleteById(id); }

    public List<Hero> topByWinRate() {
        List<Hero> all = new ArrayList<>(repo.findAll());
        all.sort(Comparator.comparingDouble(Hero::getWinRate).reversed());
        return all;
    }

    public ImportResult loadFromSavedFile(Path path) {
        int added = 0, dups = 0, errors = 0, skipped = 0;

        try (BufferedReader br = Files.newBufferedReader(path)) {
            String line;
            while ((line = br.readLine()) != null) {
                line = line.trim();
                if (line.isEmpty()) continue;

                String[] info = line.split("\\s*-\\s*", 7);
                if (info.length != 7) {
                    skipped++;
                    continue;
                }
                String id = info[0].trim(), name = info[1].trim(), hpS = info[2].trim(),
                        spS = info[3].trim(), ultS = info[4].trim(), role = info[5].trim(), wrS = info[6].trim();

                if (!isValidHeroId(id)) {
                    errors++;
                    continue;
                }
                Integer hp = HealthPointFormat(hpS);
                if (hp == null) {
                    errors++;
                    continue;
                }
                Integer sp = MovementSpeedFormat(spS);
                if (sp == null) {
                    errors++;
                    continue;
                }
                Integer ult = UltDamageFormat(ultS);
                if (ult == null) {
                    errors++;
                    continue;
                }
                String roleN = HeroRoleFormat(role);
                if (roleN == null) {
                    errors++;
                    continue;
                }
                Double wr = WinRateFormat(wrS);
                if (wr == null) {
                    errors++;
                    continue;
                }
                if (repo.existsById(id)) {
                    dups++;
                    continue;
                }

                Hero h = new Hero(id, name.trim().replaceAll("\\s+", " "),
                        hp, sp, ult, roleN, wr);
                repo.save(h);
                added++;
            }
        } catch (IOException ioe) {
            throw new RuntimeException("Error loading from saved file", ioe);
        }
        return new ImportResult(added, dups, errors, skipped);
    }
    // generate report has been also used from previous phase
    public Path generateWinRateReport (Path out) {
        List<Hero> list = topByWinRate();
        if (list.isEmpty()) throw new IllegalStateException("No heroes to be added to the PDF.");

        try {
            Document doc = new Document(PageSize.A4);
            PdfWriter.getInstance(doc, new FileOutputStream(out.toFile()));
            doc.open();

            Font title = new Font(Font.FontFamily.TIMES_ROMAN, 22, Font.BOLD);
            doc.add(new Paragraph("Marvel Rivals Heroes Win Rate % Report", title));
            doc.add(new Paragraph(" "));

            PdfPTable t = new PdfPTable(7);
            t.setWidthPercentage(100);
            t.setWidths(new float[]{1.2f,2.5f,1.2f,1.2f,1.5f,2f,1.5f});

            Font head = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, BaseColor.WHITE);
            BaseColor red = new BaseColor(255, 0, 0);
            for (String h : new String[] {"ID","Hero Name","Health Point","Mov. Speed","Ultimate Damage","Hero Role","Win Rate (%)"}) {
                PdfPCell c = new PdfPCell(new Phrase(h, head));
                c.setBackgroundColor(red);
                c.setHorizontalAlignment(Element.ALIGN_CENTER);
                t.addCell(c);
            }

            for (Hero h : list) {
                t.addCell(h.getIdentityHeroID());
                t.addCell(h.getHeroName());
                t.addCell(Integer.toString(h.getHealthPoint()));
                t.addCell(Integer.toString(h.getMovementSpeed()));
                t.addCell(Integer.toString(h.getUltDamage()));
                t.addCell(h.getHeroRole());
                t.addCell(String.format("%.2f", h.getWinRate()));
            }
            doc.add(t);
            doc.close();
            return out;
        } catch (Exception e) {
            throw new RuntimeException("PDF Generation error", e);
        }
    }

    private void validate (Hero h) {
        if(!isValidHeroId(h.getIdentityHeroID())) throw new IllegalArgumentException("ID must be 3 digits");
        if (h.getHeroName()==null || h.getHeroName().isBlank() || h.getHeroName().trim().split("\\s+").length>3)
            throw new IllegalArgumentException("Name must be 1–3 words.");
        if (h.getHealthPoint()<250 || h.getHealthPoint()>900) throw new IllegalArgumentException("HP 250–900.");
        if (h.getMovementSpeed()<6 || h.getMovementSpeed()>9) throw new IllegalArgumentException("Speed 6–9.");
        if (h.getUltDamage()<300 || h.getUltDamage()>9999) throw new IllegalArgumentException("Ult 300–9999.");
        if (HeroRoleFormat(h.getHeroRole())==null) throw new IllegalArgumentException("Role Duelist/Strategist/Vanguard.");
        if (h.getWinRate()<0 || h.getWinRate()>100) throw new IllegalArgumentException("WinRate 0–100.");
    }

    public static boolean isValidHeroId(String id) { return id!=null && id.matches("\\d{3}"); }
    public static Integer HealthPointFormat(String s){ try{int v=Integer.parseInt(s); return (v<250||v>900)?null:v;}catch(Exception e){return null;} }
    public static Integer MovementSpeedFormat(String s){ try{int v=Integer.parseInt(s); return (v<6||v>9)?null:v;}catch(Exception e){return null;} }
    public static Integer UltDamageFormat(String s){ try{int v=Integer.parseInt(s); return (v<300||v>9999)?null:v;}catch(Exception e){return null;} }
    public static String HeroRoleFormat(String role) {
        if (role == null) return null;
         return switch (role.trim().toLowerCase(Locale.ROOT)) {
            case "duelist" -> "Duelist";
            case "strategist" -> "Strategist";
            case "vanguard" -> "Vanguard";
            default -> null;
        };
    }
public static Double WinRateFormat(String s) {try{double v=Double.parseDouble(s); return (v<0 || v>100)?null:v;} catch (Exception e){return null;} }
    }