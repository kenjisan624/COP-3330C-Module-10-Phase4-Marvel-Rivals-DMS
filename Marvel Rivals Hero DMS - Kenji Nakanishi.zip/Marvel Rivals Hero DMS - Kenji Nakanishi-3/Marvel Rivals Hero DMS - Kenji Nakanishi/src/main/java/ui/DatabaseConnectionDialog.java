package ui;

import db.Database;
import javax.swing.*;
import java.awt.*;

// Prompt user to browse for .db file interface windows to the user
// Once user successfully load the file, the connection will be shown as connected...!
public class DatabaseConnectionDialog extends JDialog {
    private final JTextField pathField;
    private boolean ok = false;

    // Selection and connection to the database
    public DatabaseConnectionDialog(Frame owner) {
        super(owner, "Connect to SQLite", true);
        pathField = new JTextField(28);
        // User Interface main components
        JButton browse = new JButton("Browse...");
        JButton connect = new JButton("Connect");
        JButton cancel = new JButton("Cancel");

        // Location of the file
        browse.addActionListener( e -> {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select SQLite .db file");
        int r = fc.showOpenDialog(this);
        if (r == JFileChooser.APPROVE_OPTION) {
        pathField.setText(fc.getSelectedFile().getAbsolutePath());
        }
        });
        // Validation for the path and file
        connect.addActionListener( e -> {
            String path = pathField.getText().trim();
            if (path.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please choose a db. file");
                return;
            }
            try {
                Database.setUrl("jdbc:sqlite:" + path);
                Database.getConnection().close();
                ok = true;
                dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to connect:\n" + ex.getMessage());
            }
        });

        // Cancel button in case none .db is found
        cancel.addActionListener( e -> dispose());
        // layout portion
        JPanel row = new JPanel(new BorderLayout(8,8));
        row.add(pathField, BorderLayout.CENTER);
        row.add(browse, BorderLayout.EAST);
        JPanel buttons = new JPanel();
        buttons.add(connect);
        buttons.add(cancel);
        setLayout(new BorderLayout(10,10));
        add(new JLabel("SQLite data file:"), BorderLayout.NORTH);
        add(row, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);
        pack();
        setLocationRelativeTo(owner);
    }

    @SuppressWarnings("ConstantConditions")
    public boolean isOk(){
        return ok;
    }
}
