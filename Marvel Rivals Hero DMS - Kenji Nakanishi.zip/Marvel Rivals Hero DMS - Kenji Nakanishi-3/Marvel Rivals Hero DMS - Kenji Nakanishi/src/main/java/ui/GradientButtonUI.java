package ui;

import javax.swing.*;
import javax.swing.plaf.basic.BasicButtonUI;
import java.awt.*;


// Tried to use Marvel Official Colours towards the design phase

public class GradientButtonUI extends BasicButtonUI {
    private final Color base = new Color(0xE23636);
    private final Color hover1 = new Color(0xE23636);
    private final Color hover2 = new Color(0x7A0F16);
    private final Color hover3 = new Color(0x111111);

    @Override
    public void installUI(JComponent c) {
        super.installUI(c);
        AbstractButton b = (AbstractButton) c;
        b.setContentAreaFilled(false);
        b.setFocusPainted(false);
        b.setBorderPainted(false);
        b.setOpaque(false);
        b.setForeground(Color.WHITE);
        b.setRolloverEnabled(true);
        b.setFont(b.getFont().deriveFont(Font.BOLD, b.getFont().getSize2D() + 1f));
        b.setMargin(new Insets(8, 12, 8, 12));
    }

    @Override
    public void paint(Graphics g, JComponent c) {
        AbstractButton b = (AbstractButton) c;
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int w = c.getWidth(), h = c.getHeight();
        ButtonModel m = b.getModel();

        if (m.isRollover() || m.isPressed()) {
            Paint p = new LinearGradientPaint(0,0,w,h,
                    new float[] {0f, 0.65f, 1f},
                    new Color[] {hover1,hover2, hover3});
            g2.setPaint(p);
        } else {
            g2.setPaint(base);
        }
        g2.fillRoundRect(0, 0, w, h, 16, 16);
        super.paint(g2, c);
        g2.dispose();
    }
}
