package ui;

import main.Hero;
import javax.swing.table.AbstractTableModel;
import java.util.ArrayList;
import java.util.List;

// Communicate between table and List<Hero>
// Check for rows and columns and what to show on each cell
public class HeroTableModel extends AbstractTableModel {
    private final String[] cols = {"ID","Name","HP","Move","Ult","Role","WinRate"};
    private final List<Hero> data = new ArrayList<>();
    private Runnable onDirty;
    public void setOnDirty(Runnable r) { this.onDirty =r;}
    public List<Hero> snapshot() {return new ArrayList<>(data);}
    public void setAll(List<Hero> heroes) {
        data.clear();
        data.addAll(heroes);
        fireTableDataChanged();
        markDirty();
    }
    public void add(Hero h){
        int i = data.size();
        data.add(h);
        fireTableRowsInserted(i, i);
        markDirty();
    }
    public void remove(int modelRow) {
        if (modelRow < 0 || modelRow >= data.size()) return;
        data.remove(modelRow);
        fireTableRowsDeleted(modelRow, modelRow);
        markDirty();
    }
    @Override public int getRowCount() { return data.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int c) { return cols[c]; }
    @Override public boolean isCellEditable(int r, int c) { return false; }
    @Override public Object getValueAt(int r, int c) {
        Hero h = data.get(r);
        return switch (c) {
            case 0 -> h.getIdentityHeroID();
            case 1 -> h.getHeroName();
            case 2 -> h.getHealthPoint();
            case 3 -> h.getMovementSpeed();
            case 4 -> h.getUltDamage();
            case 5 -> h.getHeroRole();
            case 6 -> h.getWinRate();
            default -> "";
        };
    }
    @Override public void setValueAt(Object v, int r, int c) {
        Hero h = data.get(r);
        try {
            String id = h.getIdentityHeroID();
            String name = h.getHeroName();
            int hp = h.getHealthPoint();
            int move = h.getMovementSpeed();
            int ult = h.getUltDamage();
            String role = h.getHeroRole();
            double rate =h.getWinRate();

            switch (c){
                case 0 -> id = String.valueOf(v);
                case 1 -> name = String.valueOf(v);
                case 2 -> hp = Integer.parseInt(v.toString());
                case 3 -> move = Integer.parseInt(v.toString());
                case 4 -> ult = Integer.parseInt(v.toString());
                case 5 -> role = String.valueOf(v);
                case 6 -> rate = Double.parseDouble(v.toString());
            }
            data.set(r, new Hero(id,name,hp,move,ult,role,rate));
            fireTableRowsUpdated(r, r);
            markDirty();
        } catch (Exception ignored) { }
    }
    private void markDirty() { if(onDirty != null) onDirty.run();}
}
