package db;

import java.sql.*;

//This java class database will be in charge of keeping connection between database
// it provides with safe open and close connections
// No longer csv or text file, straightforward .db!
public final class Database {
    //JDBC URL for the .db
    private static String url;
    // CONN for connection
    private static Connection CONN;
    private static volatile boolean initialized  = false;

    private Database() {}
    // initialization state
    public static synchronized void setUrl (String jdbcUrl) {
        url =jdbcUrl;
        initialized  = false;
        closeQuietly();
    }
    // Ensure connection to the SQLite database
    // whenever no connection found, it will try to open
    public static synchronized Connection getConnection() throws SQLException {
        if (url == null || url.isBlank()) {
            throw new IllegalStateException("Database URL is not set!");
        }
        if(CONN == null || CONN.isClosed()) {
        CONN = DriverManager.getConnection(url);
        try (Statement st = CONN.createStatement()) {
            st.execute("Pragma journal_mode=WAL;");
            st.execute("PRAGMA foreign_keys=ON;");
             }
        }
        ensureSchema(CONN);
        return CONN;
    }

    // Make sure the heroes table exists in the database
    // creates an index for data integrity
    private static synchronized void ensureSchema(Connection c)  {
        if(initialized) return;
        String createHeroes ="""
                CREATE TABLE IF NOT EXISTS heroes (
                    id          TEXT PRIMARY KEY,
                    name        TEXT NOT NULL,
                    hp          INTEGER,
                    move        INTEGER,
                    ult         INTEGER,
                    role        TEXT,
                    win_rate    REAL
                    );
            """;
            String uniq = """
                    CREATE UNIQUE INDEX IF NOT EXISTS ux_heroes_id ON heroes(id);
                """;
                try {
                    boolean oldAuto = c.getAutoCommit();
                    c.setAutoCommit(false);
                    try (Statement st = c.createStatement()) {
                        st.execute(createHeroes);
                        st.execute(uniq);
                    }
                    c.commit();
                    c.setAutoCommit(oldAuto);
                    initialized = true;
        } catch (SQLException e) {
            try { c.rollback(); } catch (Exception ignore) {}
                    throw new RuntimeException("Schema init failed"+ e.getMessage(), e);
        }
    }
    //  Terminate connection with the database if still exists.
    // Called when exiting the app
    public static synchronized void closeQuietly() {
        if (CONN != null){
            try { CONN.close(); } catch (Exception ignore) {}
            CONN = null;
        }
    }
}
